# Full-Stack Todo Application

A modern todo application built with React (Frontend) and Express (Backend) using TypeScript.

## Project Structure

