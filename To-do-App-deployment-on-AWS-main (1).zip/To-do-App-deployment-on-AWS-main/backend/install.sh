#!/bin/bash
npm install express cors dotenv drizzle-orm pg
npm install -D typescript @types/express @types/cors @types/node @types/pg drizzle-kit ts-node ts-node-dev 