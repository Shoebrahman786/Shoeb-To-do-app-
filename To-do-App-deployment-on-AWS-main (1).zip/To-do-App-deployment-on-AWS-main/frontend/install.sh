#!/bin/bash
npm install -D vite @types/react @types/react-dom @vitejs/plugin-react typescript
npm install react react-dom @tanstack/react-query react-hot-toast axios zustand @heroicons/react 